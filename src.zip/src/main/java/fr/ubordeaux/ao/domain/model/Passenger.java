package fr.ubordeaux.ao.domain.model;

public class Passenger {

    private String id;
    private String firstName;
    private String lastName;

    public Passenger(String id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }
    
    @Override
    public boolean equals(Object other) {
        if (other instanceof Passenger) {
            Passenger otherPass = (Passenger) other;
            boolean equals = this.getId().compareTo(otherPass.getId()) == 0;
            boolean equals2 = this.getFirstName().compareTo(otherPass.getFirstName()) == 0;
            boolean equals3 = this.getLastName().compareTo(otherPass.getLastName()) == 0;
            return equals && equals2 && equals3;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return "Passenger{" +
                "id='" + id + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }
}
