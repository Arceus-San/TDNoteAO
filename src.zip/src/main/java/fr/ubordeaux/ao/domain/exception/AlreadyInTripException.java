package fr.ubordeaux.ao.domain.exception;

public class AlreadyInTripException extends Exception {

    public AlreadyInTripException(String message) {
        super(message);
    }
}
