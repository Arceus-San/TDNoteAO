package fr.ubordeaux.ao.domain.exception;

public class LocationException extends Exception {

    public LocationException(String message) {
        super(message);
    }
}
